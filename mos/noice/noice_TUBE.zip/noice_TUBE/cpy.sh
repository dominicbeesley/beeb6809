cp MON6809-dom1.bin /cygdrive/I/6809/MON
