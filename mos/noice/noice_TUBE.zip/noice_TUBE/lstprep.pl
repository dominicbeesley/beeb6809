#/bin/perl

while (<>) {
  chomp;
  my $l = $_;
  if ($l =~ /([A-F0-9]{4})\s\s([A-F0-9\s]{16})(.*)/i) {
    my $addr = lc($1), $ops = lc($2), $rest = $3;
    my $sep;

    if ($ops =~ /^\s+$/ && $rest =~ /\s+(EQU|ORG)/) {
    	$sep = "=";
    }
    else {
    	$sep = ":";
    }

    $rest =~ s/^([A-Z0-9_]+)\s(.*)/\1:\2/i;

    print "$addr $sep $ops $rest\n";
  } else {
	$l =~ s/\;//gi;
	
    print "$l\n";
  }
}