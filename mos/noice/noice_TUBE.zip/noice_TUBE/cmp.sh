#!/bin/bash 

src=MON6809-dom1

asm6809 -v -o $src.bin -l $src.lst $src.asm
x=$?
if [[ $x -ne 0 ]]; then
	exit $x;
fi

perl lstprep.pl <$src.lst >$src.ls2
perl lstprep.pl <$src.asm >$src.as2
